
package com.biopet.mutation
import androidx.compose.ui.geometry.Offset

data class MutationNode(
    val id: String,
    val title: String,
    val unlocked: Boolean,
    val position: Offset,
    val legendary: Boolean = false
)

data class MutationEdge(val from: String, val to: String)
