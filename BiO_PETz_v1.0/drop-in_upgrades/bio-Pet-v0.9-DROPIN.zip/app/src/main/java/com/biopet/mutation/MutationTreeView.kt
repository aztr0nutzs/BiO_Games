
package com.biopet.mutation
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.foundation.Canvas
import androidx.compose.ui.graphics.*
import androidx.compose.ui.geometry.*
import androidx.compose.animation.core.*
import com.biopet.ui.*

@Composable
fun MutationTreeView(nodes: List<MutationNode>, edges: List<MutationEdge>) {
    val anim = rememberInfiniteTransition()
    val pulse by anim.animateFloat(0.8f, 1.2f, infiniteRepeatable(tween(1200), RepeatMode.Reverse))
    Canvas(Modifier.fillMaxSize()) {
        edges.forEach { e ->
            val from = nodes.find { it.id == e.from }?.position ?: Offset.Zero
            val to = nodes.find { it.id == e.to }?.position ?: Offset.Zero
            val path = Path().apply { moveTo(from.x, from.y); lineTo(to.x, to.y) }
            drawPath(path, NeonPurple, style = Stroke(4f))
        }
        nodes.forEach { n ->
            drawCircle(
                color = if (n.unlocked) NeonCyan else Color.DarkGray,
                radius = if (n.legendary) 24f * pulse else 18f,
                center = n.position
            )
        }
    }
}
