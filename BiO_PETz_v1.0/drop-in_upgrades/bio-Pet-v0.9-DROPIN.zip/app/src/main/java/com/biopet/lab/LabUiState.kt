
package com.biopet.lab
import com.biopet.mutation.*

data class LabUiState(
    val instability: Int = 0,
    val corruption: Int = 0,
    val nodes: List<MutationNode> = emptyList(),
    val edges: List<MutationEdge> = emptyList()
)
